<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<style>body {padding: 0;margin: 0;background-color: #fefdf4;font-family: 'Merriweather Sans', Arial, Helvetica, sans-serif;font-size: 14px;}nav {background-color: #000>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Pathway+Gothic+One&amp;family=Merriweather+Sans:wght@300;400;500;700;800&amp;display=swap" as="st>
  </head>
  <body>
    <nav>
      <a target="_blank" href="https://atomicat.com.br" style="padding:0;margin:0;">
        <img style="height:32px;" src="https://img.imageboss.me/atm/cdn/u/0B1zizlSngfFNS7TlZ858AKj77o1/l/cmlClc2154804.webp" alt="logo">
      </a>
      <div style="display:flex;gap:24px;">
        <a class="icon" href="https://ajuda.atomicat.com.br" target="_blank">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-postcard-fill" viewBox="0 0 16 16">
            <path d="M11 8h2V6h-2v2Z"/>
            <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4Zm8.5.5a.5.5 0 0 0-1 0v7a.5.5 0 0 0 1 0v-7ZM2 5.5a.5.5 0 0 0 .5.5H6a.5.5 0 0 0 0->
          </svg>
          Central de ajuda
        </a>
        <a class="icon login" href="https://app.atomicat.com.br/login" target="_blank">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-bar-right" viewBox="0 0 16 16">
            <path fill-rule="evenodd" d="M6 8a.5.5 0 0 0 .5.5h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 0 0-.708.708L12.293 7.5H6.5A.5.5 0 0>
          </svg>
          Faça login
        </a>
      </div>
    </nav>
    <div class="caixa">
      <div>
        <h1 id="dominio">
          Melhor pegar um GPS...
        </h1>
        <h3>Parece que você está perdido. Não há nada para ver aqui.</h3>
        <p>
          Caso tenha alguma dúvida, clique na logo para visitar a nossa página e fale com o nosso suporte. Ou então, clique em Central de Ajuda e confira os nossos tutoria>
        </p>
      </div>
      <img class="imagem" src="https://img.imageboss.me/atm/cdn/u/0B1zizlSngfFNS7TlZ858AKj77o1/l/PBwGob4879018.png" alt="">
    </div>
  </body>
</html>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v84a3a4012de94ce1a686ba8c167c359c1696973893317" integrity="sha512-euoFGowhlaLqXsPWQ48qSkBSCFs3DPRyiwVu3FjR96cMPx+Fr+gpWRhIafcHwqwCqWS42RZhIudOvEI+Ckf6MA==" data-cf-beacon='{"rayId":"81c2975859df1f81","b":1,"version":"2023.10.0","token":"ef0707825bc44ac891f71e954cb732e3"}' crossorigin="anonymous"></script>
